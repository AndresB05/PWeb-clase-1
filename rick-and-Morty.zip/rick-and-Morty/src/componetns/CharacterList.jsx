import {useEffect, useState } from 'react';
import Character from './Character'

function CharacterList () {

    const [characters, setcharacters] = useState([]);
    const [loading, setloading] = useState(true)

    useEffect(()=> {
     async function fetchData() { 
     const response = await fetch('https://rickandmortyapi.com/api/character')
     const data = await response.json()
     setloading(false)
     setcharacters(data.results)
    }
  
    fetchData()
    }, []);

    if (loading) {
        return (
            <div>Loading</div>
        )
    }

    return (
        <div className='container'>  
         {
            loading ? <h1>Loading...</h1> :
            <div className="row">
         {characters.map((character) => {
              return (
                <div className='col-md-4' key={character.id}>
                     <Character character={character} />
                </div>
              );
            })}
         </div>
         }
        </div>
    )
}

export default CharacterList